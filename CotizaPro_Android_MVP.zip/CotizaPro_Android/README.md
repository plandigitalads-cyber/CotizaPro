# CotizaPro Android

MVP nativo para Android dirigido a gasfíteres y plomeros de Chile.

## Requisitos
- Android Studio reciente
- JDK 17
- Android SDK 35
- Conexión a Internet para descargar dependencias Gradle

## Abrir
1. Descomprime el proyecto.
2. Abre la carpeta `CotizaPro_Android` desde Android Studio.
3. Espera la sincronización de Gradle.
4. Ejecuta en un emulador o teléfono Android.

## Incluye
- Inicio y resumen de cotizaciones
- Creación de presupuestos con materiales y costos
- Cálculo de total, utilidad y margen
- Clientes derivados de cotizaciones
- Catálogo inicial de trabajos
- Historial y estados
- PDF y compartir mediante Android Sharesheet
- Persistencia local inicial mediante SharedPreferences/JSON

## Limitaciones conocidas del MVP
Esta es una primera base funcional, no una versión final certificada ni lista para publicar en Play Store.
- Los datos se guardan localmente en un único dispositivo.
- La configuración del negocio, respaldo/importación y edición avanzada de clientes quedan para la siguiente iteración.
- El catálogo muestra plantillas de referencia; todavía no inserta automáticamente líneas en una cotización.
- El PDF inicial es básico y debe personalizarse antes de vender.
- No incluye sincronización en nube, cuentas ni pagos.
- Debe compilarse y probarse en Android Studio antes de distribuirse.

## Próxima etapa
Completar Room + DataStore, configuración de negocio, edición de cotizaciones, respaldo, pruebas automatizadas y firma de release APK.
