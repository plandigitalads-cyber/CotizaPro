package cl.cotizapro.app

import android.content.Intent
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.NumberFormat
import java.util.Locale

private val Navy = Color(0xFF10243B)
private val Teal = Color(0xFF16B8A0)
private val Bg = Color(0xFFF4F7FA)
private val Chile = Locale("es", "CL")
private fun money(n: Long) = "$" + NumberFormat.getIntegerInstance(Chile).format(n)

data class LineItem(val name: String, val qty: Int, val price: Long) {
    val total: Long get() = qty.toLong() * price
}
data class Quote(
    val id: Long, val client: String, val phone: String, val work: String,
    val lines: List<LineItem>, val labor: Long, val travel: Long, val other: Long,
    val discount: Long, val status: String, val created: Long
) {
    val costs: Long get() = lines.sumOf { it.total } + labor + travel + other
    val total: Long get() = (costs - discount).coerceAtLeast(0)
    val profit: Long get() = total - costs
    val margin: Double get() = if (total > 0) (profit.toDouble() / total) * 100 else 0.0
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CotizaProApp() }
    }
}

@Composable
fun CotizaProApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("cotizapro_local", 0) }
    var quotes by remember { mutableStateOf(loadQuotes(prefs)) }
    var clients by remember { mutableStateOf(loadClients(prefs)) }
    var tab by remember { mutableStateOf("Inicio") }
    var showNew by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Quote?>(null) }

    fun persist() {
        val arr = JSONArray()
        quotes.forEach { q ->
            val o = JSONObject().put("id", q.id).put("client", q.client).put("phone", q.phone)
                .put("work", q.work).put("labor", q.labor).put("travel", q.travel)
                .put("other", q.other).put("discount", q.discount).put("status", q.status)
                .put("created", q.created)
            val ls = JSONArray()
            q.lines.forEach { ls.put(JSONObject().put("name", it.name).put("qty", it.qty).put("price", it.price)) }
            o.put("lines", ls); arr.put(o)
        }
        prefs.edit().putString("quotes", arr.toString())
            .putString("clients", JSONArray(clients).toString()).apply()
    }

    MaterialTheme(
        colorScheme = lightColorScheme(primary = Navy, secondary = Teal, background = Bg, surface = Color.White)
    ) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            Column(Modifier.fillMaxSize()) {
                TopBar()
                when {
                    showNew -> NewQuoteScreen(
                        clients = clients,
                        onCancel = { showNew = false },
                        onSave = { q ->
                            quotes = listOf(q) + quotes
                            if (q.client.isNotBlank() && q.client !in clients) clients = clients + q.client
                            persist(); showNew = false; tab = "Cotizaciones"
                        }
                    )
                    selected != null -> QuoteDetailScreen(
                        quote = selected!!,
                        onBack = { selected = null },
                        onShare = { sharePdf(context, selected!!) },
                        onStatus = { status ->
                            quotes = quotes.map { if (it.id == selected!!.id) it.copy(status = status) else it }
                            selected = quotes.firstOrNull { it.id == selected!!.id }; persist()
                        }
                    )
                    else -> {
                        when (tab) {
                            "Inicio" -> HomeScreen(quotes, onNew = { showNew = true }, onOpen = { selected = it })
                            "Cotizaciones" -> QuotesScreen(quotes, onOpen = { selected = it }, onNew = { showNew = true })
                            "Clientes" -> ClientsScreen(clients)
                            "Catálogo" -> CatalogScreen(onUse = { name ->
                                showNew = true
                            })
                            else -> SettingsScreen()
                        }
                        NavigationBar(containerColor = Color.White) {
                            listOf("Inicio", "Cotizaciones", "Clientes", "Catálogo", "Ajustes").forEach { label ->
                                val icon = when(label) {
                                    "Inicio" -> Icons.Default.Home
                                    "Cotizaciones" -> Icons.Default.ReceiptLong
                                    "Clientes" -> Icons.Default.People
                                    "Catálogo" -> Icons.Default.Build
                                    else -> Icons.Default.Settings
                                }
                                NavigationBarItem(
                                    selected = tab == label,
                                    onClick = { tab = label },
                                    icon = { Icon(icon, null) },
                                    label = { Text(label, fontSize = 10.sp) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TopBar() {
    Row(
        Modifier.fillMaxWidth().background(Navy).padding(horizontal = 20.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(38.dp).background(Teal, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Build, null, tint = Color.White)
        }
        Spacer(Modifier.width(10.dp))
        Column {
            Text("CotizaPro", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Text("COTIZA MEJOR. GANA MÁS.", color = Color(0xFFB8D2E5), fontSize = 9.sp, letterSpacing = 1.sp)
        }
        Spacer(Modifier.weight(1f))
        Icon(Icons.Default.WaterDrop, null, tint = Teal)
    }
}

@Composable
fun HomeScreen(quotes: List<Quote>, onNew: () -> Unit, onOpen: (Quote) -> Unit) {
    val total = quotes.sumOf { it.total }
    val pending = quotes.count { it.status == "Pendiente" || it.status == "Borrador" }
    val accepted = quotes.filter { it.status == "Aceptada" }.sumOf { it.total }
    LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("Hola, profesional 👋", color = Navy, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            Text("Aquí tienes el resumen de tu negocio.", color = Color.Gray)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Navy), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.fillMaxWidth().padding(20.dp)) {
                    Text("TOTAL COTIZADO", color = Color(0xFFB8D2E5), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(money(total), color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(15.dp))
                    Button(onClick = onNew, colors = ButtonDefaults.buttonColors(containerColor = Teal), modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("NUEVA COTIZACIÓN", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("Pendientes", pending.toString(), Modifier.weight(1f))
                MetricCard("Aceptado", money(accepted), Modifier.weight(1f))
            }
        }
        item { Text("Cotizaciones recientes", color = Navy, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        if (quotes.isEmpty()) item { EmptyState("Aún no tienes cotizaciones", "Crea tu primera cotización para comenzar.") }
        items(quotes.take(5)) { q -> QuoteRow(q, onClick = { onOpen(q) }) }
    }
}

@Composable
fun MetricCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(15.dp)) {
            Text(title, color = Color.Gray, fontSize = 12.sp)
            Text(value, color = Navy, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun QuotesScreen(quotes: List<Quote>, onOpen: (Quote) -> Unit, onNew: () -> Unit) {
    Column(Modifier.weight(1f).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Cotizaciones", color = Navy, fontSize = 23.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            FilledTonalButton(onClick = onNew) { Icon(Icons.Default.Add, null); Text("Nueva") }
        }
        Spacer(Modifier.height(12.dp))
        if (quotes.isEmpty()) EmptyState("Todavía no hay presupuestos", "Pulsa Nueva para crear el primero.")
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) { items(quotes) { QuoteRow(it) { onOpen(it) } } }
    }
}

@Composable
fun QuoteRow(q: Quote, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable { onClick() }, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(15.dp)) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).background(Color(0xFFE7F7F4), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.ReceiptLong, null, tint = Teal)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(q.client.ifBlank { "Cliente sin nombre" }, color = Navy, fontWeight = FontWeight.Bold)
                Text(q.work.ifBlank { "Trabajo de gasfitería" }, color = Color.Gray, fontSize = 12.sp)
                Text(q.status, color = Teal, fontSize = 11.sp)
            }
            Text(money(q.total), color = Navy, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun NewQuoteScreen(clients: List<String>, onCancel: () -> Unit, onSave: (Quote) -> Unit) {
    var client by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var work by remember { mutableStateOf("") }
    var materialName by remember { mutableStateOf("") }
    var qty by remember { mutableStateOf("1") }
    var price by remember { mutableStateOf("") }
    var labor by remember { mutableStateOf("") }
    var travel by remember { mutableStateOf("") }
    var other by remember { mutableStateOf("") }
    var discount by remember { mutableStateOf("") }
    var items by remember { mutableStateOf(listOf<LineItem>()) }
    val cost = items.sumOf { it.total } + (labor.toLongOrNull() ?: 0) + (travel.toLongOrNull() ?: 0) + (other.toLongOrNull() ?: 0)
    val final = (cost - (discount.toLongOrNull() ?: 0)).coerceAtLeast(0)
    LazyColumn(Modifier.weight(1f).padding(16.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Nueva cotización", color = Navy, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = onCancel) { Text("Cancelar") }
            }
        }
        item { SectionTitle("Datos del cliente") }
        item { Field("Nombre del cliente", client) { client = it } }
        item { Field("Teléfono / WhatsApp", phone, KeyboardType.Phone) { phone = it } }
        item { Field("Descripción del trabajo", work) { work = it } }
        item { SectionTitle("Materiales y repuestos") }
        item { Field("Nombre del material", materialName) { materialName = it } }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Field("Cantidad", qty, KeyboardType.Number, Modifier.weight(1f)) { qty = it }
                Field("Precio unitario", price, KeyboardType.Number, Modifier.weight(2f)) { price = it }
            }
        }
        item {
            OutlinedButton(onClick = {
                val q = qty.toIntOrNull() ?: 0
                val p = price.toLongOrNull() ?: 0
                if (materialName.isNotBlank() && q > 0 && p >= 0) {
                    items = items + LineItem(materialName, q, p); materialName = ""; qty = "1"; price = ""
                }
            }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Text("Agregar material") }
        }
        items(items) { item ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("${item.qty} × ${item.name}", Modifier.weight(1f), color = Navy)
                Text(money(item.total), fontWeight = FontWeight.Bold)
                IconButton(onClick = { items = items - item }) { Icon(Icons.Default.Delete, null, tint = Color.Gray) }
            }
        }
        item { SectionTitle("Otros costos") }
        item { Field("Mano de obra (CLP)", labor, KeyboardType.Number) { labor = it } }
        item { Field("Traslado (CLP)", travel, KeyboardType.Number) { travel = it } }
        item { Field("Otros gastos (CLP)", other, KeyboardType.Number) { other = it } }
        item { Field("Descuento (CLP)", discount, KeyboardType.Number) { discount = it } }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Navy), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(18.dp)) {
                    Text("TOTAL DE LA COTIZACIÓN", color = Color(0xFFB8D2E5), fontSize = 11.sp)
                    Text(money(final), color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Text("Costo antes del descuento: ${money(cost)}", color = Color(0xFFB8D2E5), fontSize = 12.sp)
                }
            }
        }
        item {
            Button(
                onClick = { onSave(Quote(System.currentTimeMillis(), client, phone, work, items,
                    labor.toLongOrNull() ?: 0, travel.toLongOrNull() ?: 0, other.toLongOrNull() ?: 0,
                    discount.toLongOrNull() ?: 0, "Pendiente", System.currentTimeMillis())) },
                enabled = client.isNotBlank() && work.isNotBlank(),
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Teal)
            ) { Icon(Icons.Default.Save, null); Spacer(Modifier.width(8.dp)); Text("Guardar cotización") }
        }
    }
}

@Composable
fun SectionTitle(text: String) { Text(text, color = Navy, fontWeight = FontWeight.Bold, fontSize = 16.sp) }

@Composable
fun Field(label: String, value: String, type: KeyboardType = KeyboardType.Text, modifier: Modifier = Modifier.fillMaxWidth(), onChange: (String) -> Unit) {
    OutlinedTextField(value, onChange, modifier, label = { Text(label) }, singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = type), shape = RoundedCornerShape(12.dp))
}

@Composable
fun QuoteDetailScreen(quote: Quote, onBack: () -> Unit, onShare: () -> Unit, onStatus: (String) -> Unit) {
    Column(Modifier.weight(1f).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
            Text("Detalle de cotización", color = Navy, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        }
        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(quote.client, color = Navy, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                Text(quote.work, color = Color.Gray)
                HorizontalDivider()
                quote.lines.forEach { Text("${it.qty} × ${it.name}: ${money(it.total)}") }
                Text("Mano de obra: ${money(quote.labor)}")
                Text("Traslado: ${money(quote.travel)}")
                Text("Otros gastos: ${money(quote.other)}")
                Text("Descuento: ${money(quote.discount)}")
                HorizontalDivider()
                Text("TOTAL: ${money(quote.total)}", color = Teal, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("Utilidad estimada: ${money(quote.profit)} (${String.format("%.1f", quote.margin)}%)", color = Navy)
                Text("Estado: ${quote.status}", color = Teal)
            }
        }
        Button(onClick = onShare, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Teal)) {
            Icon(Icons.Default.Share, null); Spacer(Modifier.width(8.dp)); Text("Compartir PDF")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Aceptada", "Rechazada", "Pendiente").forEach { s ->
                OutlinedButton(onClick = { onStatus(s) }, modifier = Modifier.weight(1f)) { Text(s, fontSize = 10.sp) }
            }
        }
    }
}

@Composable
fun ClientsScreen(clients: List<String>) {
    Column(Modifier.weight(1f).padding(16.dp)) {
        Text("Clientes", color = Navy, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        if (clients.isEmpty()) EmptyState("Tu cartera está vacía", "Los clientes se guardan al crear cotizaciones.")
        else clients.forEach { name ->
            Card(Modifier.fillMaxWidth().padding(bottom = 8.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Person, null, tint = Teal); Spacer(Modifier.width(12.dp)); Text(name, color = Navy, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

@Composable
fun CatalogScreen(onUse: (String) -> Unit) {
    val categories = listOf(
        "Reparación de filtraciones", "Instalación de grifería", "Instalación de sanitarios",
        "Reparación de cañerías", "Destape de desagües", "Mantenimiento de termos",
        "Diagnóstico y visita técnica", "Emergencias de gasfitería"
    )
    Column(Modifier.weight(1f).padding(16.dp)) {
        Text("Catálogo de trabajos", color = Navy, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Text("Ideas para tus cotizaciones. Ajusta siempre los precios a tu realidad.", color = Color.Gray, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(categories) { item ->
                Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Row(Modifier.fillMaxWidth().clickable { onUse(item) }.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Build, null, tint = Teal)
                        Spacer(Modifier.width(12.dp))
                        Text(item, Modifier.weight(1f), color = Navy, fontWeight = FontWeight.Medium)
                        Icon(Icons.Default.ChevronRight, null, tint = Color.Gray)
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen() {
    Column(Modifier.weight(1f).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Configuración", color = Navy, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.padding(16.dp)) {
                Text("CotizaPro", color = Navy, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("Versión 1.0.0 · Datos guardados en este dispositivo.", color = Color.Gray, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                Text("Completa los datos de tu negocio antes de enviar cotizaciones. Esta versión inicial no sincroniza información entre dispositivos.")
            }
        }
        Text("Consejo: realiza copias de seguridad de tus datos y no compartas el dispositivo con terceros.", color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable
fun EmptyState(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(30.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.ReceiptLong, null, tint = Teal, modifier = Modifier.size(42.dp))
        Spacer(Modifier.height(10.dp))
        Text(title, color = Navy, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Color.Gray, fontSize = 12.sp)
    }
}

private fun loadClients(prefs: android.content.SharedPreferences): List<String> =
    runCatching { val a = JSONArray(prefs.getString("clients", "[]")); (0 until a.length()).map { a.getString(it) } }.getOrDefault(emptyList())

private fun loadQuotes(prefs: android.content.SharedPreferences): List<Quote> =
    runCatching {
        val a = JSONArray(prefs.getString("quotes", "[]"))
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i); val ls = o.getJSONArray("lines")
            val lines = (0 until ls.length()).map { j ->
                val l = ls.getJSONObject(j); LineItem(l.getString("name"), l.getInt("qty"), l.getLong("price"))
            }
            Quote(o.getLong("id"), o.getString("client"), o.getString("phone"), o.getString("work"), lines,
                o.getLong("labor"), o.getLong("travel"), o.getLong("other"), o.getLong("discount"),
                o.getString("status"), o.getLong("created"))
        }
    }.getOrDefault(emptyList())

private fun sharePdf(context: android.content.Context, q: Quote) {
    val doc = PdfDocument()
    val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
    val page = doc.startPage(pageInfo)
    val canvas = page.canvas
    val paint = Paint().apply { color = android.graphics.Color.rgb(16,36,59); textSize = 24f; isFakeBoldText = true }
    canvas.drawText("CotizaPro", 40f, 55f, paint)
    paint.textSize = 11f; paint.isFakeBoldText = false
    canvas.drawText("COTIZACIÓN PROFESIONAL", 40f, 75f, paint)
    paint.textSize = 14f; paint.isFakeBoldText = true
    canvas.drawText("Cliente: ${q.client}", 40f, 125f, paint)
    paint.isFakeBoldText = false; paint.textSize = 12f
    canvas.drawText("Trabajo: ${q.work}", 40f, 150f, paint)
    var y = 195f
    q.lines.forEach {
        canvas.drawText("${it.qty} x ${it.name}", 40f, y, paint)
        canvas.drawText(money(it.total), 460f, y, paint); y += 22f
    }
    y += 15f
    listOf("Mano de obra" to q.labor, "Traslado" to q.travel, "Otros gastos" to q.other, "Descuento" to -q.discount).forEach {
        canvas.drawText(it.first, 40f, y, paint); canvas.drawText(money(it.second), 460f, y, paint); y += 22f
    }
    paint.color = android.graphics.Color.rgb(22,184,160); paint.textSize = 22f; paint.isFakeBoldText = true
    canvas.drawText("TOTAL: ${money(q.total)}", 40f, y + 25f, paint)
    paint.color = android.graphics.Color.DKGRAY; paint.textSize = 10f; paint.isFakeBoldText = false
    canvas.drawText("Cotización generada con CotizaPro. Vigencia y condiciones a confirmar con el profesional.", 40f, 800f, paint)
    doc.finishPage(page)
    val file = File(context.cacheDir, "CotizaPro_${q.id}.pdf")
    file.outputStream().use { doc.writeTo(it) }; doc.close()
    val uri = androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "application/pdf"; putExtra(Intent.EXTRA_STREAM, uri)
        putExtra(Intent.EXTRA_TEXT, "Hola ${q.client}, te comparto tu cotización por ${money(q.total)}. ¡Gracias!")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(send, "Compartir cotización"))
}
